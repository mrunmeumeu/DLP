import React from 'react';
import { Link } from 'react-router-dom';  // Import Link from react-router-dom
import styles from './SidebarMenu.module.css';

const menuItems = [
  { icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/e952f119c916e716f4a93171a48969ff341d047766d5c870e61f46e40f554413?placeholderIfAbsent=true&apiKey=6780ef7663fb420989788dbe5af024d1", label: "Dashboard", link: "/", active: false },
  { icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/3aa412be8bccf6d101ee840cee87ae5b1f96cb9d72e76b88b7b880fe2d456c08?placeholderIfAbsent=true&apiKey=6780ef7663fb420989788dbe5af024d1", label: "USB Monitoring", link: "/usb", active: false },
  { icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/d046b6dc07ee19941d1127f57da9b7735b9677c00ec4aa3dc42273ea68466f3d?placeholderIfAbsent=true&apiKey=6780ef7663fb420989788dbe5af024d1", label: "Keyword Management", link: "/keyword-management", active: false },
  { icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/e5d8d3b584b1b8049ae0da516faa6d19cb360094933dffd01a2774d2d72541f9?placeholderIfAbsent=true&apiKey=6780ef7663fb420989788dbe5af024d1", label: "Executable Monitoring", link: "/executable-monitoring", active: true },
  { icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/b07822cdefb0a7273bca5e9b5bfecfd1ea4da8b4d2e426fdf43dd6427c066720?placeholderIfAbsent=true&apiKey=6780ef7663fb420989788dbe5af024d1", label: "VA Scans", link: "/va-scans", active: false },
];

function SidebarMenu() {
  return (
    <nav className={styles.sidebarMenu}>
      {menuItems.map((item, index) => (
        <Link 
          key={index} 
          to={item.link}  // Use 'Link' for client-side navigation
          className={`${styles.menuItem} ${item.active ? styles.active : ''}`}
        >
          <img src={item.icon} alt={item.label} className={styles.menuIcon} />
          <span>{item.label}</span>
        </Link>
      ))}
    </nav>
  );
}

export default SidebarMenu;
