import React from "react";
import { Link } from 'react-router-dom';  // Import Link from react-router-dom
import styles from './SidebarMenu.module.css';

const menuItems = [
  { icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/dd75c4dd9dcbc16889b345acf1d84b2b2df6e66d6f96da7811622ec41172af2c?placeholderIfAbsent=true&apiKey=6780ef7663fb420989788dbe5af024d1", label: "Dashboard", link: "/", active: false },
  { icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/5504c4596ff0a31ee27c0c48e238bf14a7bd47d921c33a5395325e321545d555?placeholderIfAbsent=true&apiKey=6780ef7663fb420989788dbe5af024d1", label: "USB Monitoring", link: "/usb", active: false },
  { icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/0a4e040319651d06f0b422eb46e45d0c4d1fabd7d2a04c886ff52e1d7effd7d4?placeholderIfAbsent=true&apiKey=6780ef7663fb420989788dbe5af024d1", label: "Keyword Management", link: "/keyword-management", active: true },
  { icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/36daae5689e414302c4ae1bb36c11d60dee4428cd6bec179f30a2c6b22081b59?placeholderIfAbsent=true&apiKey=6780ef7663fb420989788dbe5af024d1", label: "Executable Monitoring", link: "/executable-monitoring", active: false },
  { icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/e490c36267b2c761eb7cb523e910e77d52f51930a4c58d93b7e66be35a259949?placeholderIfAbsent=true&apiKey=6780ef7663fb420989788dbe5af024d1", label: "VA Scans", link: "/va-scans", active: false },
];

function SidebarMenu() {
  return (
    <nav className={styles.sidebarMenu}>
      {menuItems.map((item, index) => (
        <Link
          key={index}
          to={item.link}  // Use Link for navigation instead of anchor tag
          className={`${styles.menuItem} ${item.active ? styles.active : ''}`}
        >
          <img src={item.icon} alt={item.label} className={styles.menuIcon} />
          <span className={styles.menuLabel}>{item.label}</span>
        </Link>
      ))}
    </nav>
  );
}

export default SidebarMenu;
